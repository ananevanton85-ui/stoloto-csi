package com.example.stolotocsi;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_FILE = 1001;
    private Spinner gameSpinner;
    private TextView output;
    private final List<int[]> rows = new ArrayList<>();

    static class Game { String name; int max; int pick; int fields; Game(String n,int m,int p,int f){name=n;max=m;pick=p;fields=f;} public String toString(){return name;} }
    private final Game[] games = new Game[]{
            new Game("Охота: 2 поля по 4 из 20",20,4,2),
            new Game("Забава: 12 из 24",24,12,1),
            new Game("Гослото 4 из 20: 2 поля по 4 из 20",20,4,2),
            new Game("Гослото 5 из 36",36,5,1),
            new Game("Гослото 6 из 45",45,6,1),
            new Game("Гослото 7 из 49",49,7,1),
            new Game("Спортлото 6 из 49",49,6,1),
            new Game("Русское лото: 15 чисел из 90",90,15,1)
    };

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,24);
        TextView title=new TextView(this); title.setText("Stoloto CSI Analyzer"); title.setTextSize(24); title.setGravity(Gravity.CENTER); root.addView(title);
        gameSpinner=new Spinner(this); gameSpinner.setAdapter(new ArrayAdapter<Game>(this, android.R.layout.simple_spinner_dropdown_item, games)); root.addView(gameSpinner);
        Button load=new Button(this); load.setText("Загрузить CSV/XLSX как CSV"); root.addView(load);
        Button demo=new Button(this); demo.setText("Показать демо-расчет"); root.addView(demo);
        output=new TextView(this); output.setTextSize(15); output.setText("Загрузи архив Столото CSV. Колонка с числами может быть вида: 1,12,15,19,19,11,7,20\n\nВажно: это аналитика прошлого архива, не гарантия выигрыша.");
        ScrollView sv=new ScrollView(this); sv.addView(output); root.addView(sv, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        load.setOnClickListener(v -> { Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*"); startActivityForResult(i,PICK_FILE); });
        demo.setOnClickListener(v -> { loadDemo(); analyze(); });
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_FILE && resultCode==RESULT_OK && data!=null){ try{ readCsv(data.getData()); analyze(); }catch(Exception e){ output.setText("Ошибка чтения файла: "+e.getMessage()); } } }

    private void readCsv(Uri uri) throws Exception{
        rows.clear();
        InputStream is=getContentResolver().openInputStream(uri);
        BufferedReader br=new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
        String line; while((line=br.readLine())!=null){
            List<Integer> nums=extractNumbers(line);
            // Ignore draw id/date noise by keeping the last expected amount of numbers where possible.
            Game g=(Game)gameSpinner.getSelectedItem(); int need=g.pick*g.fields;
            if(nums.size()>=need){ int[] arr=new int[need]; for(int i=0;i<need;i++) arr[i]=nums.get(nums.size()-need+i); rows.add(arr); }
        }
        br.close();
    }

    private List<Integer> extractNumbers(String s){
        List<Integer> list=new ArrayList<>(); StringBuilder cur=new StringBuilder();
        for(int i=0;i<s.length();i++){ char c=s.charAt(i); if(Character.isDigit(c)){ cur.append(c); } else { if(cur.length()>0){ int n=Integer.parseInt(cur.toString()); if(n>=1 && n<=90) list.add(n); cur.setLength(0);} } }
        if(cur.length()>0){ int n=Integer.parseInt(cur.toString()); if(n>=1 && n<=90) list.add(n); }
        return list;
    }

    private void loadDemo(){
        rows.clear(); int[][] sample={{1,12,15,19,19,11,7,20},{5,11,18,20,2,8,16,19},{7,10,11,15,5,11,19,20},{4,7,15,16,5,10,12,20},{2,10,18,20,1,6,17,19},{5,10,11,18,2,5,8,19}};
        rows.addAll(Arrays.asList(sample));
    }

    private void analyze(){
        Game g=(Game)gameSpinner.getSelectedItem(); if(rows.isEmpty()){ output.setText("Нет данных для анализа."); return; }
        StringBuilder sb=new StringBuilder(); sb.append("Игра: ").append(g.name).append("\nТиражей в файле: ").append(rows.size()).append("\n\n");
        for(int f=0; f<g.fields; f++) analyzeField(sb,g,f);
        sb.append("\nФормула: для одного поля всего C(").append(g.max).append(",").append(g.pick).append(") = ").append(comb(g.max,g.pick)).append(" равновозможных комбинаций.\n");
        sb.append("Вероятность конкретной комбинации: 1/").append(comb(g.max,g.pick)).append(". CSI только ранжирует варианты по архиву.\n");
        output.setText(sb.toString());
    }

    private void analyzeField(StringBuilder sb, Game g, int field){
        int start=field*g.pick; Map<Integer,Integer> freq=new HashMap<>(); Map<String,Integer> pair=new HashMap<>();
        for(int[] r: rows){ if(r.length<start+g.pick) continue; int[] nums=Arrays.copyOfRange(r,start,start+g.pick); Arrays.sort(nums); for(int n:nums) freq.put(n,freq.getOrDefault(n,0)+1); for(int i=0;i<nums.length;i++) for(int j=i+1;j<nums.length;j++){ String k=nums[i]+"-"+nums[j]; pair.put(k,pair.getOrDefault(k,0)+1);} }
        sb.append("Поле ").append(field+1).append("\nГорячие числа: "); for(Map.Entry<Integer,Integer> e: top(freq,10)) sb.append(e.getKey()).append("(").append(e.getValue()).append(") "); sb.append("\nСильные пары: "); for(Map.Entry<String,Integer> e: top(pair,8)) sb.append(e.getKey()).append("(").append(e.getValue()).append(") "); sb.append("\n");
        List<int[]> combos=new ArrayList<>(); genComb(1,g.max,g.pick,new int[g.pick],0,combos);
        PriorityQueue<Scored> pq=new PriorityQueue<>(Comparator.comparingDouble(a->a.score));
        for(int[] c: combos){ double sc=score(c,freq,pair,g); if(pq.size()<10) pq.add(new Scored(c,sc)); else if(sc>pq.peek().score){ pq.poll(); pq.add(new Scored(c,sc)); }}
        List<Scored> best=new ArrayList<>(pq); best.sort((a,b)->Double.compare(b.score,a.score));
        sb.append("Топ CSI:\n"); int rank=1; for(Scored s: best){ sb.append(rank++).append(") ").append(arr(s.c)).append("  CSI=").append(String.format(Locale.US,"%.2f",s.score)).append("\n"); }
        sb.append("\n");
    }

    private double score(int[] c, Map<Integer,Integer> freq, Map<String,Integer> pair, Game g){
        double s=0; for(int n:c) s+=freq.getOrDefault(n,0); for(int i=0;i<c.length;i++) for(int j=i+1;j<c.length;j++) s+=0.7*pair.getOrDefault(c[i]+"-"+c[j],0);
        int even=0,sum=0; for(int n:c){ if(n%2==0) even++; sum+=n; }
        int idealEven=g.pick/2; s-=Math.abs(even-idealEven)*2.0; double idealSum=g.pick*(g.max+1)/2.0; s-=Math.abs(sum-idealSum)*0.03; return s;
    }

    static class Scored { int[] c; double score; Scored(int[] c,double s){this.c=c;score=s;} }
    private <K> List<Map.Entry<K,Integer>> top(Map<K,Integer> m,int n){ List<Map.Entry<K,Integer>> l=new ArrayList<>(m.entrySet()); l.sort((a,b)->b.getValue()-a.getValue()); return l.subList(0, Math.min(n,l.size())); }
    private void genComb(int from,int max,int left,int[] cur,int pos,List<int[]> out){ if(left==0){ out.add(cur.clone()); return; } for(int i=from;i<=max-left+1;i++){ cur[pos]=i; genComb(i+1,max,left-1,cur,pos+1,out);} }
    private long comb(int n,int k){ long r=1; for(int i=1;i<=k;i++) r=r*(n-k+i)/i; return r; }
    private String arr(int[] a){ StringBuilder s=new StringBuilder(); for(int i=0;i<a.length;i++){ if(i>0)s.append(" • "); s.append(a[i]); } return s.toString(); }
}
